# Display name and image of each AFDSI ontology as the item

from BaseCollection import BaseCollection
from html import *

class Collection(BaseCollection):
    PAGE_TITLE = ''
    PAGE_HEADING = ''
    PAGE_SUBHEADING = ''

# Change these values to customize the page layout
    ITEMS_PER_GROUP = 5
    ITEMS_PER_ROW = 5
    ITEMS_PER_HISTORY_ROW = 4
    ITEMS_PER_GROUPED_PAGE = 99
    ITEMS_PER_UNGROUPED_PAGE = 40

    def __init__(self, db):
        self.db = db
        self.facetlist = db.facetlist # show all facets

# Don't show attributes that contain URLs
        self.attrlist = [
            attr for attr in db.attrlist
            if attr not in ['name_usual', 'wikipedia_url', 'photo_logo']]

    def itemdisplay(self, item, request):
        metadata = self.db.metadata(item)
        links = []
        if metadata['wikipedia_url']:
            links += [br, link(metadata['wikipedia_url'], 'Wikipedia')]
        return [img(metadata['photo_logo']), br,
                metadata['name_usual'], br, links]

    def itemlisting(self, item, index, link=None, query=None, **args):
        metadata = self.db.metadata(item)
        listing = [img(metadata['photo_logo']), br,
                   abbrev(metadata['name_usual'], 20)]
        if link:
            listing = link(listing, query=query, index=index)
        return listing
